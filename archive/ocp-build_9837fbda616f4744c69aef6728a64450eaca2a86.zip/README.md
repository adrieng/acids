## To clone

    git clone git@github.com:OCamlPro/ocp-build.git
    cd ocp-build

## To build

Configure:

    ./configure -prefix /usr/local

Build:

    make

Install:

    make install

Build and read the documentation:

    make doc
    cd docs/user-manual
    evince user-manual.pdf

